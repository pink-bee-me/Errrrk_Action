# CreatingTheCodePortfolio_OnGoDaddy
Portfolio Website
This is the repo for my CreatingTheCode.com portfolio website.
I have included all of the asset files. 
I am including an audio clip on the website (because I like it). 
This is my first endeavor of this kind.
So, Here's to many more repos and many more improvements in all areas!!!
Thank You To The Instructors @ The Tech Academy.
Cheers To Me... I am actually doing this thing called "Life!!!"
Yay Me!!!
Here's to you Dad... It's not the same without you, but I keep on keeping on... I'm keeping my promise... I'm gonna make you proud.
Wish You Were Here... I miss you so much.
